Mass Clean Data
-------------------------------------------------

Odoo Version : Odoo 15.0 Community


Installation
-------------------------------------------------------------
Install the Application => Apps -> Mass Clear Data(clean_data)



